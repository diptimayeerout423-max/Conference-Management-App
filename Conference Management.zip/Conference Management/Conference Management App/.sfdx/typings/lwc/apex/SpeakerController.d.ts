declare module "@salesforce/apex/SpeakerController.searchSpeakers" {
  export default function searchSpeakers(param: {name: any, speciality: any}): Promise<any>;
}
declare module "@salesforce/apex/SpeakerController.getSessionsByDate" {
  export default function getSessionsByDate(param: {sessionDate: any}): Promise<any>;
}
declare module "@salesforce/apex/SpeakerController.checkAvailability" {
  export default function checkAvailability(param: {speakerId: any, sessionId: any}): Promise<any>;
}
declare module "@salesforce/apex/SpeakerController.createSessionAndAssignment" {
  export default function createSessionAndAssignment(param: {speakerId: any, sessionDate: any}): Promise<any>;
}
declare module "@salesforce/apex/SpeakerController.createAssignment" {
  export default function createAssignment(param: {speakerId: any, sessionId: any}): Promise<any>;
}
