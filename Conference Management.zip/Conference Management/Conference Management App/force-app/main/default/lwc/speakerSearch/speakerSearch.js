import { LightningElement } from 'lwc';

export default class SpeakerSearch extends LightningElement {

    name = '';
    speciality = '';

    specialityOptions = [
        { label: 'Apex', value: 'Apex' },
        { label: 'LWC', value: 'LWC' },
        { label: 'Integrations', value: 'Integrations' },
        { label: 'Architecture', value: 'Architecture' }
    ];

    handleNameChange(event) {
        this.name = event.target.value;
    }

    handleSpecialityChange(event) {
        this.speciality = event.detail.value;
    }

    handleSearch() {
    console.log('Search clicked:', this.name, this.speciality);

    this.dispatchEvent(
        new CustomEvent('search', {
            detail: {
                name: this.name,
                speciality: this.speciality
            }
        })
    );
}

}