import { LightningElement, track } from 'lwc';
import searchSpeakers from '@salesforce/apex/SpeakerController.searchSpeakers';

export default class SpeakerManager extends LightningElement {

    @track speakers = [];
    @track selectedSpeaker;

   handleSearch(event) {
    const { name, speciality } = event.detail;

    console.log('Received search:', name, speciality);

    searchSpeakers({ name, speciality })
        .then(result => {
            console.log('Apex result:', result);
            this.speakers = result;
        })
        .catch(error => {
            console.error('Apex error:', error);
        });
}


    handleSpeakerSelect(event) {
        this.selectedSpeaker = event.detail;
    }
}