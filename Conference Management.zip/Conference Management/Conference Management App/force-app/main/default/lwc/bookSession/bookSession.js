import { LightningElement, api, track } from 'lwc';
import getSessionsByDate from '@salesforce/apex/SpeakerController.getSessionsByDate';
import createAssignment from '@salesforce/apex/SpeakerController.createAssignment';
import createSessionAndAssignment
    from '@salesforce/apex/SpeakerController.createSessionAndAssignment';
import checkAvailability from '@salesforce/apex/SpeakerController.checkAvailability';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class BookSession extends LightningElement {

    dateSelected = false;
hasSessions = false;

    @api speaker;

    selectedDate;
    selectedSessionId;

    @track sessionOptions = [];
    disableButton = true;
    


    get hasSpeaker() {
        return !!this.speaker;
    }

    // 📅 Date selection
  handleDateChange(event) {
    this.selectedDate = event.target.value;
    this.dateSelected = true;   // ✅ IMPORTANT
    this.sessionOptions = [];
    this.selectedSessionId = null;
    this.disableButton = true;
    this.hasSessions = false;

    if (!this.selectedDate) return;

    getSessionsByDate({ sessionDate: this.selectedDate })
        .then(result => {
    if (result.length === 0) {
        this.hasSessions = false;
        this.disableButton = false; // ✅ allow click
        return;
    }

    this.hasSessions = true;
    this.disableButton = true; // wait until session selected
    this.sessionOptions = result.map(s => ({
        label: `${s.Name} (${s.Start_Time__c} - ${s.End_Time__c})`,
        value: s.Id
    }));
})

}

    

    // 📌 Session selected
    handleSessionChange(event) {
        this.selectedSessionId = event.detail.value;
        this.disableButton = true;

        if (!this.selectedSessionId) return;

        checkAvailability({
            speakerId: this.speaker.Id,
            sessionId: this.selectedSessionId
        })
        .then(isAvailable => {
            if (isAvailable) {
                this.disableButton = false;
            } else {
                this.showToast(
                    'Error',
                    'Speaker is already booked for this time',
                    'error'
                );
            }
        });
    }

    // ✅ Create Assignment
    handleCreate() {

        // CASE 1️⃣ Sessions exist → normal assignment
        if (this.hasSessions && this.selectedSessionId) {
            createAssignment({
                speakerId: this.speaker.Id,
                sessionId: this.selectedSessionId
            })
            .then(() => {
                this.showToast(
                    'Success',
                    'Assignment created successfully',
                    'success'
                );
                this.disableButton = true;
            })
            .catch(error => {
                this.showToast('Error', error.body.message, 'error');
            });
            return;
        }

        // CASE 2️⃣ No session → auto-create session + assignment
        createSessionAndAssignment({
            speakerId: this.speaker.Id,
            sessionDate: this.selectedDate
        })
        .then(() => {
            this.showToast(
                'Success',
                'Session and Assignment created automatically',
                'success'
            );
            this.disableButton = true;
        })
        .catch(error => {
            this.showToast('Error', error.body.message, 'error');
        });
    }

    showToast(title, message, variant) {
        this.dispatchEvent(
            new ShowToastEvent({ title, message, variant })
        );
    }
}